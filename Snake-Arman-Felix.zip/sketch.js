/**
 * Created by Simon on 12/10/2016.
 */
var s;
var food;
var isStarted = false;
var canvasWidth = 0;
var canvasHeight = 0;
var speed = 0;
var foodColor = "";
var xspeed = 0;
var yspeed = 0;
var foodX;
var foodY;
var cols;
var rows;
var width;
var height;

function start() {
    //window.alert("A");
    //createCanvas(500, 500);
	isStarted = true;
    width = document.getElementById("width").value;
    height = document.getElementById("height").value;
	canvasHeight = height * s.scl;
	canvasWidth = width * s.scl;
	s.x = parseInt(document.getElementById("width").value/2)*s.scl;
	s.y = parseInt(document.getElementById("height").value/2)*s.scl;
	var cnv = createCanvas(canvasWidth, canvasHeight);
    var marginSide = (windowWidth - width) / 2;
    var marginTop = (windowHeight - height) / 2;
    cnv.position(marginSide, marginTop);
    speed = map(document.getElementById("speed").value, 1, 5, 5, 15);
    frameRate(speed);
    s.snakeColor = document.getElementById("snake").value;
    s.snakeHeadColor = document.getElementById("snakeHead").value;
    foodColor = document.getElementById("food").value;
	s.xspeed = 0;
    s.yspeed = 0;
	s.total = 0;
	s.tail = [];
    pickLocation();
    document.getElementById("settings").innerHTML = "";
    document.getElementById("scoreTable").style.visibility="visible";
    cols = canvasWidth/ s.scl;
    rows = canvasHeight/ s.scl;

}

function direction(x, y) {
    xspeed = x;
    yspeed = y;
    if(!isStarted) isStarted = true;
}

function setup() { 
    s = new Snake();

}

function checkPickedLocation(x, y) {
    var f = createVector(floor(x), floor(y));
    for(var i = 0; i < s.tail.length; i++) {
        if (f.x == s.tail[i].x/ s.scl && f.y == s.tail[i].y/ s.scl) {
            return false;
        }
    }
    return true;
}

function pickLocation() {
    foodX = random(0, cols);
    foodY = random(0, rows);
    if(s.tail.length > 0) {
        if(checkPickedLocation(foodX, foodY)) {
            food = createVector(floor(foodX), floor(foodY));
            food.mult(s.scl);
        }
        else {
            pickLocation();
        }
    } else {
        food = createVector(floor(foodX), floor(foodY));
        food.mult(s.scl);
    }


}

function pause() {
    s.yspeed = 0;
    s.xspeed = 0;
    isStarted = false;
    window.alert("Pause!! \n Press Direction button to move.")
}

function keyPressed() {

    if(keyCode == UP_ARROW) {
        direction(0, -1);
    } else if(keyCode == DOWN_ARROW) {
        direction(0, 1);
    } else if(keyCode == RIGHT_ARROW) {
        direction(1, 0);
    } else if(keyCode == LEFT_ARROW) {
        direction(-1, 0);
    } else if(keyCode == 80) {
        console.log("pause");
        pause();
    }
}

function draw() {

	if(isStarted) {
        background(51);
		if(s.eat(food)) {
			pickLocation();
            document.getElementById("score").innerHTML = s.total+1;
		}
        //console.log(s.x);
        s.dir(xspeed, yspeed);
		s.death();
		s.canvasEdge();
		s.update();
		s.show();

		fill(foodColor);
		rect(food.x, food.y, s.scl, s.scl);
	}
}

