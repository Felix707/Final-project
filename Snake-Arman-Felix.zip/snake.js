/**
 * Created by Simon on 12/10/2016.
 */
function Snake() {
    this.x = 0;
    this.y = 0;
    this.scl = 15;
    this.xspeed = 0;
    this.yspeed = 0;
	this.total = 0;
	this.tail = [];
    this.snakeColor = 0;
    this.snakeHeadColor = 0;

	

    this.dir = function (x, y) {
        if(this.xspeed * x != -1) this.xspeed = x;
        if(this.yspeed * y != -1) this.yspeed = y;
    }
	
	this.canvasEdge = function() {
        if(this.x == width) {
            this.x = 0;
        } else if(this.x == -this.scl) {
            this.x = width;
        }

		if(this.y == height) {
			this.y = 0;	
		} else if(this.y == -this.scl) {
			this.y = height;
		}
	
		
	}

    this.win = function() {
        if(this.total+1 == width * height) {
            this.total = 0;
            this.tail = [];
            window.alert('Game Over!!!');
            isStarted = false;
        }
    }

	this.death = function() {
		for(var i = 0; i < this.tail.length; i++) {
			var pos = this.tail[i];
			var d = dist(this.x, this.y, pos.x, pos.y);
			if(d < 1)
			{
				this.total = 0;
				this.tail = [];
				window.alert('Game Over!!!');
				isStarted = false;
                location.reload();
			}
		}
		
	}

    this.eat = function(pos){
        var d = dist(this.x, this.y, pos.x, pos.y);
        if(d < 1) {
            this.total++;
			return true;
        } else {
            return false;
        }
    }

    this.update = function() {
		if(this.total == this.tail.length) {
			for(var i = 0; i < this.tail.length-1; i++) {
				this.tail[i] = this.tail[i+1];
			}
			
		}
		
		this.tail[this.total-1] = createVector(this.x, this.y);
		
        this.x = this.x + this.xspeed*this.scl;
        this.y = this.y + this.yspeed*this.scl;

        //this.x = constrain(this.x, -this.scl, width);
        //this.y = constrain(this.y, -this.scl, height);
    }

    this.show = function() {
        fill(this.snakeColor);
		for(var i = 0; i < this.tail.length; i++)  {
			rect(this.tail[i].x, this.tail[i].y, this.scl, this.scl);
		}
        fill(this.snakeHeadColor);
        rect(this.x, this.y, this.scl, this.scl);
    }
}