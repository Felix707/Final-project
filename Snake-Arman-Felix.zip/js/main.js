/**
 * Created by Simon on 9/20/2015.
 */

function validateRegisterForm() {
    var usernameRegEx = /^(?=.{4,20}$)[a-zA-Z0-9]+$/;
    var passwordRegEx = /((?=.*\d)(?=.*[a-z]*)(?=.*[A-Z]*)(?=.*[@#$%!]*).{6,20})/;
    var username = document.getElementById("username").value;
    var password = document.getElementById("inputPassword").value;
    var password2 = document.getElementById("confirmPassword").value;
    if (username == "" || username == null) {
        alert("Please enter username!");
        document.getElementById("username").focus();
        return false;
    }
    else {
        if(!usernameRegEx.test(username)) {
            alert("Please enter valid username!");
            document.getElementById("username").focus();
            return false;
        }
    }
    if (password == "" || password == null) {
        alert("Please enter password!");
        document.getElementById("inputPassword").focus();
        return false;
    }
    else {
        if(!passwordRegEx.test(password)) {
            alert("Please enter valid password!");
            document.getElementById("inputPassword").focus();
            return false;
        }
    }
    if (password2 != password) {
        alert("Password isn't matching!");
        document.getElementById("confirmPassword").focus();
        return false;
    }
}